// ***********************************************
// Create various custom commands and overwrite existing commands.
// ***********************************************
