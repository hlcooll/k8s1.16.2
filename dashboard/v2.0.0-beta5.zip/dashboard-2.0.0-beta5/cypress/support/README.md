The `support/index.js` is processed and
loaded automatically before the test files.

This is the place to put global configuration and
behavior that modifies Cypress.
