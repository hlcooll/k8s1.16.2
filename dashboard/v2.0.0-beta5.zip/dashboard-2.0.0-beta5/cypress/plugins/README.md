The `plugins/index.js` file is used to load plugins.

You can read more here: https://on.cypress.io/plugins-guide
