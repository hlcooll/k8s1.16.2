Fixtures are mock data used during tests, promoting repeatability.

You can read more here: https://github.com/cypress-io/cypress-example-recipes/tree/master/examples/fundamentals__fixtures
