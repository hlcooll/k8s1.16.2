# FAQ

___It will be moved soon, for now you can [visit Wiki](https://github.com/kubernetes/dashboard/wiki/FAQ).___

----
_Copyright 2019 [The Kubernetes Dashboard Authors](https://github.com/kubernetes/dashboard/graphs/contributors)_
